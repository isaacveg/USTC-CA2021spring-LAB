# cache 实验所需的文件

 * main_mem.sv 和 mem.sv 是我们提供的主存代码，cache代码会调用它们
 * cache.sv 是我们提供的直接相连cache的代码。
 * generate_cache_tb.py 是我们提供的，用于生成 cache 测试testbench的python代码
 * cache_tb.sv 是一个由 generate_cache_tb.py 生成的testbench

